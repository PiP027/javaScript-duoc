<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-slider/slider.css'; ?>
</style>

<!--Slider-->

<div id="carouselExampleControls" class="carousel slide col-12" data-ride="carousel" data-interval="5000">

    <div class="carousel-inner">
        <?php
        $active = true;
        $temp = $wp_query;
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $post_per_page = 5; // -1 shows all posts
        $args = array(
            'post_type' => 'slider',
            'orderby' => 'date',
            'order' => 'ASC',
            'paged' => $paged,
            'posts_per_page' => $post_per_page
        );
        $wp_query = new WP_Query($args);

        if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>

                <div class="carousel-item <?php if ($active) {
                                                print("active");
                                            }; ?>">
                    <?php $active = false; ?>
                
                <div id="c-slider" class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div id="info-slider" class="slider-content">
                                <h1><?php echo get_the_title();?></h1>
                                <p><?php echo get_the_excerpt();?></p>
                                
                                <div class="botones">
                                    <li id="li-nav" class="li-none">
									<a class="boton-sli solid" href="#" class="btn btn-outline-primary"><?php the_field('boton_start');?></a>
                                    </li>
                                    <li id="li-nav" class="li-none">
									<a class="boton-sli solid" href="#" class="btn btn-outline-primary"><?php the_field('boton_download') ;?></a>
								    </li>
                                </div>
                            </div>
                        </div>
                        <div id="img-slider" class="col-md-6">
                            <?php smash_tema_post_thumbnail();?>
                        </div>
                    </div>
                </div>

                </div>

            <?php endwhile; ?>

        <?php endif;
        wp_reset_query();
        $wp_query = $temp ?>

    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">siguiente etapa</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Etapa anterior</span>
    </a>
</div>