<?php  /*  Registro de mi CPT */


function slider_register() {

    $labels = array(
        'name' => _x('slider', 'post type general name'),
        'singular_name' => _x('slider', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'slider item'),
        'add_new_item' => __('Agregar nuevo slider'),
        'edit_item' => __('Editar slider'),
        'new_item' => __('Nuevo slider'),
        'view_item' => __('Ver el slider'),
        'search_items' => __('Buscar slider'),
        'not_found' =>  __('No se encontro slider'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'usuarios-slider ' ),
        'rewrite' => array('slug' => 'slider', 'with_front' => FALSE)
      ); 

    register_post_type( 'slider' , $args );
}

add_action('init', 'slider_register');


/*usuarioss personalizadas para slider*/
function usuarios_slider() {

	register_taxonomy(
		'usuarios-slider',
		'slider',
		array(
			'label' => __( 'usuarios slider' ),
			'rewrite' => array( 'slug' => 'usuarios-slider' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'usuarios_slider' );