<?php  /*  Registro de mi CPT */


function team_register() {

    $labels = array(
        'name' => _x('team', 'post type general name'),
        'singular_name' => _x('team', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'team item'),
        'add_new_item' => __('Agregar nuevo team'),
        'edit_item' => __('Editar team'),
        'new_item' => __('Nuevo team'),
        'view_item' => __('Ver el team'),
        'search_items' => __('Buscar team'),
        'not_found' =>  __('No se encontro team'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'usuarios-team ' ),
        'rewrite' => array('slug' => 'team', 'with_front' => FALSE)
      ); 

    register_post_type( 'team' , $args );
}

add_action('init', 'team_register');


/*usuarioss personalizadas para team*/
function usuarios_team() {

	register_taxonomy(
		'usuarios-team',
		'team',
		array(
			'label' => __( 'usuarios team' ),
			'rewrite' => array( 'slug' => 'usuarios-team' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'usuarios_team' );