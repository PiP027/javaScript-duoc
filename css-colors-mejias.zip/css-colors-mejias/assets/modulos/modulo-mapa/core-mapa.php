<?php  /*  Registro de mi CPT */


function mapa_register() {

    $labels = array(
        'name' => _x('mapa', 'post type general name'),
        'singular_name' => _x('mapa', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'mapa item'),
        'add_new_item' => __('Agregar nuevo mapa'),
        'edit_item' => __('Editar mapa'),
        'new_item' => __('Nuevo mapa'),
        'view_item' => __('Ver el mapa'),
        'search_items' => __('Buscar mapa'),
        'not_found' =>  __('No se encontro mapa'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'usuarios-mapa ' ),
        'rewrite' => array('slug' => 'mapa', 'with_front' => FALSE)
      ); 

    register_post_type( 'mapa' , $args );
}

add_action('init', 'mapa_register');


/*usuarioss personalizadas para mapa*/
function usuarios_mapa() {

	register_taxonomy(
		'usuarios-mapa',
		'mapa',
		array(
			'label' => __( 'usuarios mapa' ),
			'rewrite' => array( 'slug' => 'usuarios-mapa' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'usuarios_mapa' );