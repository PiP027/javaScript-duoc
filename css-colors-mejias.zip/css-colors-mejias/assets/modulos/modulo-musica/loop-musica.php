<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-musica/musica.css'; ?>
</style>

<div class="container-fluid mb-5 px-0 my-0">
<table class="table table-dark table-borderless">
<input type="text" value="0" id="bandera" class="d-none">
<thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">img</th>
      <th scope="col">Album</th>
      <th scope="col">Artista</th>
      <th scope="col">Duracion</th>
    </tr>
  </thead>
    <?php
        $temp = $wp_query;
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $post_per_page = -1; //-1 Muestra todos los post
        $args = array(
            'post_type' => 'musica',
            'orderby' => 'date',
            'order' => 'DESC',
            'paged' => $paged,
            'posts_per_page' => $post_per_page
        );
        $wp_query = new WP_Query($args);

        if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
        <tbody>
          
            <tr class="pb-1 border-top">
              <th scope="row">#</th>
              <td class="thumbnail-list-spotify"><?php cpt_mejias_post_thumbnail();?></td>
              <td><?php the_field('album');?></td>
              <td><?php the_field('artista');?></td>
              <td><?php the_field('duracion');?></td>
            </tr>
          
        
      
        <?php endwhile; else : ?>

        <p class="text-center title-sm mb-0">Oops!, Lo sentimos, No hay contenido que mostrar</p> 

        <?php endif;
        wp_reset_query();
        $wp_query = $temp ?>
  </tbody>
</table>
</div>