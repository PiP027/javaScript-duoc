<style>
  <?php include get_template_directory() . '/assets/modulos/modulo-testimonial/testimonial.css'; ?>
</style>

<div class="container contenedor-testimonio">


  <?php
  $temp = $wp_query;
  $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
  $post_per_page = -1; //-1 Muestra todos los post
  $args = array(
    'post_type' => 'testimonial',
    'orderby' => 'date',
    'order' => 'DESC',
    'paged' => $paged,
    'posts_per_page' => $post_per_page
  );
  $wp_query = new WP_Query($args);

  if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>

      <div class="testimonio">
        <p id="testimonio"><?php echo get_the_excerpt(); ?></p>
      </div>
      <div id="targeta-testimonio" class="d-flex justify-content-between">
        <div class="info-testimonio d-flex align-items-center">
          <div class="img-testimonio">
            <?php smash_tema_post_thumbnail(); ?>
          </div>

          <div class="autor-info">
            <h5 class="nombre"><?php echo get_the_title(); ?></h5>
            <p class="especialidad"><?php the_field('especialidad_autor'); ?></p>
          </div>
          </div>
          <div class="autor-review">
            <ul class="estrellas d-flex p-0 m-0">
              <li><i class="fa-solid fa-star stars"></i></li>
              <li><i class="fa-solid fa-star stars"></i></li>
              <li><i class="fa-solid fa-star stars"></i></li>
              <li><i class="fa-solid fa-star stars"></i></li>
              <li><i class="fa-solid fa-star stars"></i></li>

            </ul>
            <span class="review-info"><?php the_field('review'); ?></span>
          </div>
        
      </div>



    <?php endwhile;
  else : ?>

    <p class="text-center title-sm mb-0">Oops!, Lo sentimos, No hay contenido que mostrar</p>

  <?php endif;
  wp_reset_query();
  $wp_query = $temp ?>

</div>