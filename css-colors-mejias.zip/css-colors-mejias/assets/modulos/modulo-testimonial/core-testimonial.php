<?php  /*  Registro de mi CPT */


function testimonial_register() {

    $labels = array(
        'name' => _x('testimonial', 'post type general name'),
        'singular_name' => _x('testimonial', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'testimonial item'),
        'add_new_item' => __('Agregar nuevo testimonial'),
        'edit_item' => __('Editar testimonial'),
        'new_item' => __('Nuevo testimonial'),
        'view_item' => __('Ver el testimonial'),
        'search_items' => __('Buscar testimonial'),
        'not_found' =>  __('No se encontro testimonial'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'usuarios-testimonial ' ),
        'rewrite' => array('slug' => 'testimonial', 'with_front' => FALSE)
      ); 

    register_post_type( 'testimonial' , $args );
}

add_action('init', 'testimonial_register');


/*usuarioss personalizadas para testimonial*/
function usuarios_testimonial() {

	register_taxonomy(
		'usuarios-testimonial',
		'testimonial',
		array(
			'label' => __( 'usuarios testimonial' ),
			'rewrite' => array( 'slug' => 'usuarios-testimonial' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'usuarios_testimonial' );