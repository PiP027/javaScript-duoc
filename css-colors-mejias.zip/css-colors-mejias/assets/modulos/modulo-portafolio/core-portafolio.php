<?php  /*  Registro de mi CPT */


function portafolio_register() {

    $labels = array(
        'name' => _x('portafolio', 'post type general name'),
        'singular_name' => _x('portafolio', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'portafolio item'),
        'add_new_item' => __('Agregar nuevo portafolio'),
        'edit_item' => __('Editar portafolio'),
        'new_item' => __('Nuevo portafolio'),
        'view_item' => __('Ver el portafolio'),
        'search_items' => __('Buscar portafolio'),
        'not_found' =>  __('No se encontro portafolio'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'categoria-portafolio ' ),
        'rewrite' => array('slug' => 'portafolio', 'with_front' => FALSE)
      ); 

    register_post_type( 'portafolio' , $args );
}

add_action('init', 'portafolio_register');


/*categorias personalizadas para portafolio*/
function categoria_portafolio() {

	register_taxonomy(
		'categoria-portafolio',
		'portafolio',
		array(
			'label' => __( 'categoria portafolio' ),
			'rewrite' => array( 'slug' => 'categoria-portafolio' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'categoria_portafolio' );