<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-portafolio/portafolio.css'; ?>
</style>


<?php
$temp = $wp_query;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$post_per_page = -1; //-1 Muestra todos los post
$args = array(
    'post_type' => 'portafolio',
    'orderby' => 'date',
    'order' => 'DESC',
    'paged' => $paged,
    'posts_per_page' => $post_per_page
);
$wp_query = new WP_Query($args);

if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>

        <div class="col-lg-3">
            <div class="portafolio-menu text-center mt-50">
            <a id="all-works-a" href="#"><?php echo get_the_excerpt();?></a>
        <ul>
            <?php echo get_the_term_list($post->ID, 'categoria-portafolio', '<li class="categoria-folio">','','</li>', '</ul>') ?>
        </div>
          
    
           
        </div>

        <div class="mt-50 col-lg-9">
            <div class="row">
                <div id="fila-porta" class="col-12">
                    <figure>
                        <?php $imagen2 = get_field('imagen_uno');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                    <figure>
                        <?php $imagen2 = get_field('imagen_dos');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                    <figure>
                        <?php $imagen2 = get_field('imagen_tres');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                </div>
            </div>

            <div class="row">
                <div id="fila-porta" class="col-12">
                    <figure>
                        <?php $imagen2 = get_field('imagen_cuarto');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                    <figure>
                        <?php $imagen2 = get_field('imagen_cinco');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                    <figure>
                        <?php $imagen2 = get_field('imagen_seis');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                </div>
            </div>

            <div class="row">
                <div id="fila-porta" class="col-12">
                    <figure>
                        <?php $imagen2 = get_field('imagen_siete');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                    <figure>
                        <?php $imagen2 = get_field('imagen_ocho');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                    <figure>
                        <?php $imagen2 = get_field('imagen_nueve');
                        $size = '300x300';
                        if ($imagen2) {
                            echo wp_get_attachment_image($imagen2, $size);
                        } ?>

                    </figure>
                </div>
            </div>

        </div>


    <?php endwhile;
else : ?>

    <p class="text-center title-sm mb-0">Oops!, Lo sentimos, No hay contenido que mostrar</p>

<?php endif;
wp_reset_query();
$wp_query = $temp ?>
