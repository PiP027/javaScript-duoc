<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-services/services.css'; ?>
</style>


<?php
$temp = $wp_query;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$post_per_page = -1; //-1 Muestra todos los post
$args = array(
    'post_type' => 'services',
    'orderby' => 'date',
    'order' => 'DESC',
    'paged' => $paged,
    'posts_per_page' => $post_per_page
);
$wp_query = new WP_Query($args);

if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>

        
        
            <div class="col-md-4 col-md-7 col-sm-9">
                <div class="section-1">
                <div class="serv-title-icon d-flex justify-content-between">
                    <h5 class="serv-title"><a id="serv-titu" href="#"><?php echo get_the_title(); ?></a></h5>
                    <figure class="p-thumbnail">
                        <i class="<?php the_field('icono_service') ;?>"></i>
                        <?php smash_tema_post_thumbnail(); ?>
                    </figure>
                </div>
                <div class="section-2">
                    <p class="serv-text"><?php echo get_the_excerpt(); ?></p>
                    <a href="#" class="serv-link">LEARN MORE</a>
                </div>
                </div>
            </div>
        



    <?php endwhile;
else : ?>

    <p class="text-center title-sm mb-0">Oops!, Lo sentimos, No hay contenido que mostrar</p>

<?php endif;
wp_reset_query();
$wp_query = $temp ?>

