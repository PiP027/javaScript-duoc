<?php  /*  Registro de mi CPT */


function questions_register() {

    $labels = array(
        'name' => _x('questions', 'post type general name'),
        'singular_name' => _x('questions', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'questions item'),
        'add_new_item' => __('Agregar nuevo questions'),
        'edit_item' => __('Editar questions'),
        'new_item' => __('Nuevo questions'),
        'view_item' => __('Ver el questions'),
        'search_items' => __('Buscar questions'),
        'not_found' =>  __('No se encontro questions'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'usuarios-questions ' ),
        'rewrite' => array('slug' => 'questions', 'with_front' => FALSE)
      ); 

    register_post_type( 'questions' , $args );
}

add_action('init', 'questions_register');


/*usuarioss personalizadas para questions*/
function usuarios_questions() {

	register_taxonomy(
		'usuarios-questions',
		'questions',
		array(
			'label' => __( 'usuarios questions' ),
			'rewrite' => array( 'slug' => 'usuarios-questions' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'usuarios_questions' );