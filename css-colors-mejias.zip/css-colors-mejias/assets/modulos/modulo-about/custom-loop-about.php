<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-about/about.css'; ?>
</style>
<div class="container">
<div class="accordion" id="accordionExample">
<?php
$temp = $wp_query;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$post_per_page = -1; //-1 Muestra todos los post
$args = array(
    'post_type' => 'about',
    'orderby' => 'date',
    'order' => 'DESC',
    'paged' => $paged,
    'posts_per_page' => $post_per_page
);
$wp_query = new WP_Query($args);

if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>



  <div class="accordion-item">
    <h2 class="accordion-header" id="heading-<?php the_ID();?>">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php the_ID();?>" aria-expanded="true" aria-controls="collapse-<?php the_ID();?>">
        <h6>Frequently Asked Questions <?php echo get_the_title() ;?></h6>
      </button>
    </h2>
    <div id="collapse-<?php the_ID();?>" class="accordion-collapse collapse show" aria-labelledby="heading-<?php the_ID();?>" data-bs-parent="#accordionExample">
      <div class="accordion-body">
       <p ><?php echo get_the_excerpt() ;?></p>
      </div>
    </div>
  </div>

    <?php endwhile;
else : ?>

    <p class="text-center title-sm mb-0">Oops!, Lo sentimos, No hay contenido que mostrar</p>

<?php endif;
wp_reset_query();
$wp_query = $temp ?>

</div>
</div>
