<?php  /*  Registro de mi CPT */


function about_register() {

    $labels = array(
        'name' => _x('about', 'post type general name'),
        'singular_name' => _x('about', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'about item'),
        'add_new_item' => __('Agregar nuevo about'),
        'edit_item' => __('Editar about'),
        'new_item' => __('Nuevo about'),
        'view_item' => __('Ver el about'),
        'search_items' => __('Buscar about'),
        'not_found' =>  __('No se encontro about'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'usuarios-about ' ),
        'rewrite' => array('slug' => 'about', 'with_front' => FALSE)
      ); 

    register_post_type( 'about' , $args );
}

add_action('init', 'about_register');


/*usuarioss personalizadas para about*/
function usuarios_about() {

	register_taxonomy(
		'usuarios-about',
		'about',
		array(
			'label' => __( 'usuarios about' ),
			'rewrite' => array( 'slug' => 'usuarios-about' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'usuarios_about' );