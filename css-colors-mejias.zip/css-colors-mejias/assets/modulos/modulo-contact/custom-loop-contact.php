<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-contact/contact.css'; ?>
</style>


<?php
$temp = $wp_query;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$post_per_page = 3; //-1 Muestra todos los post
$args = array(
    'post_type' => 'contact',
    'orderby' => 'date',
    'order' => 'DESC',
    'paged' => $paged,
    'posts_per_page' => $post_per_page
);
$wp_query = new WP_Query($args);

if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>

        

        <!--<div class="info-contacto pt-30">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="info-iconos">
                            <div class="icono-contacto">
                                the_field('icono');?>
                            </div>
                            <div class="info-contacto-mapa">
                                echo get_the_excerpt();?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-lg-12">
                    <div class="formulario-contancto">
                        <h4></h4>
                        <form action="">
                            <div class="row">
                            <div class="col-md-6">hola</div>
                            <div class="col-md-6">hola</div>
                            <div class="col-md-12">hola</div>
                            <div class="col-md-12">hola</div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>-->

    <?php endwhile;
else : ?>

    <p class="text-center title-sm mb-0">Oops!, Lo sentimos, No hay contenido que mostrar</p>

<?php endif;
wp_reset_query();
$wp_query = $temp ?>