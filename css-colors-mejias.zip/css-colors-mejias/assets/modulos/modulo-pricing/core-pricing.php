<?php  /*  Registro de mi CPT */


function pricing_register() {

    $labels = array(
        'name' => _x('pricing', 'post type general name'),
        'singular_name' => _x('pricing', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'pricing item'),
        'add_new_item' => __('Agregar nuevo pricing'),
        'edit_item' => __('Editar pricing'),
        'new_item' => __('Nuevo pricing'),
        'view_item' => __('Ver el pricing'),
        'search_items' => __('Buscar pricing'),
        'not_found' =>  __('No se encontro pricing'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'usuarios-pricing ' ),
        'rewrite' => array('slug' => 'pricing', 'with_front' => FALSE)
      ); 

    register_post_type( 'pricing' , $args );
}

add_action('init', 'pricing_register');


/*usuarioss personalizadas para pricing*/
function usuarios_pricing() {

	register_taxonomy(
		'usuarios-pricing',
		'pricing',
		array(
			'label' => __( 'usuarios pricing' ),
			'rewrite' => array( 'slug' => 'usuarios-pricing' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'usuarios_pricing' );