<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-pricing/pricing.css'; ?>
</style>


<?php
$temp = $wp_query;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$post_per_page = -1; //-1 Muestra todos los post
$args = array(
    'post_type' => 'pricing',
    'orderby' => 'date',
    'order' => 'DESC',
    'paged' => $paged,
    'posts_per_page' => $post_per_page
);
$wp_query = new WP_Query($args);

if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>

        <div class="col-lg-4">
            <div class="mt-30">
                <div class="icono-pricing text-center">
                    <?php smash_tema_post_thumbnail(); ?>
                </div>
                <div class=" text-center">
                    <h5 class="titulo-pricing"><?php echo get_the_title(); ?></h5>
                    <div id="orden" class="row">
                        <div class="col-12">
                            <?php the_field('precio_plans'); ?>                        
                            <?php the_field('mensualidad_plans'); ?> 
                        </div>

                    </div>

                </div>
                <div class="lista-pricing">
                    <ul class="list-none">
                        <li>
                            <p class="desc-plans"><?php the_field('descripcion_plans'); ?></p>
                        </li>
                        <li>
                            <p class="desc-plans"><?php echo get_the_excerpt(); ?></p>
                        </li>
                    </ul>
                </div>
                <div class="plans-btn rounded-buttons text-center">
                    <a id="pricing" class="start-btn rounded-one" href="#"><?php the_field('boton_plans'); ?></a>
                </div>
            </div>

        </div>

    <?php endwhile;
else : ?>

    <p class="text-center title-sm mb-0">Oops!, Lo sentimos, No hay contenido que mostrar</p>

<?php endif;
wp_reset_query();
$wp_query = $temp ?>
</tbody>
</table>