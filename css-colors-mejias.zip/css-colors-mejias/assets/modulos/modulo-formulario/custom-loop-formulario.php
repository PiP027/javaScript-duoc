<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-formulario/formulario.css'; ?>
</style>

<div class="container mb-5">
    <div class="row">
        <?php
        $temp = $wp_query;
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $post_per_page = -1; // -1 shows all posts
        $args = array(
            'post_type' => 'formulario',
            'orderBy' => 'date',
            'order' => 'DESC',
            'paged' => $paged,
            'posts_per_page' => $post_per_page
        );

        $wp_query = new WP_Query($args);

        if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>



                <div class="email-name d-flex justify-content-evenly">
                    <div class="col-md-6">
                        <?php the_field('label_name'); ?>
                        <?php the_field('input_name'); ?>
                    </div>
                    <div class="col-md-6">
                        <?php the_field('label_email'); ?>
                        <?php the_field('input_email'); ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <?php the_field('label_mesagge'); ?>
                    <?php the_field('input_mesagge'); ?>
                </div>
                <div class="boton-formulario">
                    <a href="#">Send Message</a>
                </div>

            <?php endwhile;
        else : ?>
            <p class="text-center title-sm mb-0">Oops! lo sentimentos, no hay contenido que mostrar</p>

        <?php endif;
        wp_reset_query();
        $wp_query = $temp ?>
    </div>
</div>