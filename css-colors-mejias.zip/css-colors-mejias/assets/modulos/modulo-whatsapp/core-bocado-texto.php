<?php  /*  Registro de mi CPT */


function bocadotexto_register() {

    $labels = array(
        'name' => _x('bocadotexto', 'post type general name'),
        'singular_name' => _x('bocadotexto', 'post type singular name'),
        'add_new' => _x('Agregar nuevo', 'bocadotexto item'),
        'add_new_item' => __('Agregar nuevo bocadotexto'),
        'edit_item' => __('Editar bocadotexto'),
        'new_item' => __('Nuevo bocadotexto'),
        'view_item' => __('Ver el bocadotexto'),
        'search_items' => __('Buscar bocadotexto'),
        'not_found' =>  __('No se encontro bocadotexto'),
        'not_found_in_trash' => __('No se encontro en la basura'),
        'parent_item_colon' => ''
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => 'post',
        'menu_icon'  => 'dashicons-format-audio',
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title', 'excerpt', 'thumbnail'),
        'taxonomies'  => array( 'usuarios-bocadotexto ' ),
        'rewrite' => array('slug' => 'bocadotexto', 'with_front' => FALSE)
      ); 

    register_post_type( 'bocadotexto' , $args );
}

add_action('init', 'bocadotexto_register');


/*usuarioss personalizadas para bocadotexto*/
function usuarios_bocadotexto() {

	register_taxonomy(
		'usuarios-bocadotexto',
		'bocadotexto',
		array(
			'label' => __( 'usuarios bocadotexto' ),
			'rewrite' => array( 'slug' => 'usuarios-bocadotexto' ),
			'hierarchical' => true,
			 // Allow automatic creation of taxonomy columns on associated post-types table?
			 'show_admin_column'   => true,
			 // Show in quick edit panel?
			 'show_in_quick_edit'  => true,
		)
	);
}
add_action( 'init', 'usuarios_bocadotexto' );