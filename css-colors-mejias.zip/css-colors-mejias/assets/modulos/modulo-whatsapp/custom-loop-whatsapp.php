<style>
    <?php include get_template_directory() . '/assets/modulos/modulo-whatsapp/whatsapp.css'; ?>
</style>


<?php
$temp = $wp_query;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$post_per_page = -1; //-1 Muestra todos los post
$args = array(
    'post_type' => 'whatsapp',
    'orderby' => 'date',
    'order' => 'DESC',
    'paged' => $paged,
    'posts_per_page' => $post_per_page
);
$wp_query = new WP_Query($args);

if (have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
        <a href="<?php the_permalink(); ?>">
            <div class="container-fluid">
                <div class="row mt-3 m-0">
                    <div class="col-12 col-md-2">
                    <figure class="foto-grupo-wsp ">
                        <?php cpt_mejias_post_thumbnail(); ?>
                    </figure>
                    </div>
                    <div class="col-12 col-md-10">
                    <h2 class=" titulo-grupo-wsp"><?php echo get_the_title(); ?></h2>
                    </div>
                </div>
            </div>
        </a>
        <hr>


    <?php endwhile;
else : ?>

    <p class="text-center title-sm mb-0">Oops!, Lo sentimos, No hay contenido que mostrar</p>

<?php endif;
wp_reset_query();
$wp_query = $temp ?>

</div>