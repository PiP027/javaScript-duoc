<?php
/*Funciones llamados de Custom Post Type*/
/*Mis estilos*/

function mis_estilos(){

	wp_register_style('mi-estilo', get_template_directory_uri() . '/assets/librerias/css/colors.css', 'all');
	wp_register_style('letritas', 'https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&family=Poppins:wght@400;500;600&display=swap', 'all');
	wp_register_style('bootstrap-css', get_template_directory_uri() .'/assets/librerias/css/bootstrap.min.css', 'all');

	wp_enqueue_style('bootstrap-css');
	wp_enqueue_style('letritas');
	wp_enqueue_style('mi-estilo');
	}

	add_action('wp_enqueue_scripts', 'mis_estilos');
	
	/*Mis estilos*/
	
	/*mis scripts*/
	
	
function mis_script(){
	
	// nos aseguramos que no estamos en el area de administracion
	
	if (!is_admin()) {
	
	// registramos nuestro script con el nombre "mi-script" y decimos que es dependiente de jQuery para que wordpress se asegure de incluir jQuery antes de este archivo
	// en adicion a las dependencias podemos indicar que este aarchivo debe ser insertado en el footer del sitio, en el lugar donde se encuente la funcion wp_footer
	// Register the script like this for a theme:
	wp_register_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js', array('jquery'), '1', true);
	wp_register_script('mi-js-personalizado', get_bloginfo('template_directory') . '/assets/librerias/js/mi-js.js', array('jquery'), '1', true);
	wp_register_script('mi-script.js', get_bloginfo('template_directory') . '/assets/librerias/js/script.js', array('jquery'), '1', true);
	
	/*encolamos los JS*/
	wp_enqueue_script('bootstrap-js', array('jquery'), false);
	wp_enqueue_script('mi-js-personalizado', array('jquery'), false);
	wp_enqueue_script('mi-script.js', array('jquery'), false);
	
	}
	}


	

	add_action("wp_enqueue_scripts", "mis_script", 1);
	/*mis scripts*/


	add_post_type_support( 'page', 'excerpt' );


	//desabilita los widget nuevos de wordpress y utiliza los antiguos
	add_filter( 'use_widgets_block_editor', '__return_false' );



// Registrar menu de navegación
function menu_colors()
{

    $locations = array(
        'menu_colors' => __('menu_colors', 'menu_colors'),
    );
    register_nav_menus($locations);
}
add_action('init', 'menu_colors');


/*zona de widgets*/
function widget_mi_sitio()
{
register_sidebar(
	array(
	'name' => 'espacio para calendario', 
	'id' => 'calendario_perzo', 
	'before_widget' => '<div id="%1$S" class="container">', 
	'after_widget' => '</div>', 
	'before_title' => '<h5 class="titulo-calendario">', 
	'after_title' => '</h5>'
));

}

add_action('widgets_init', 'widget_mi_sitio');
/*zona de widgets*/

/*llamado de font-awesome*/

add_action( 'wp_enqueue_scripts', 'fonts_style_sheet' );

function fonts_style_sheet(){
	wp_enqueue_style( 'custom-stylesheet', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css');
}
/*llamado de font-awesome*/




	/*llamado a modulos*/
	include get_template_directory() . '/assets/modulos/modulo-slider/core-slider.php';

	
	
	/*llamado a modulos*/
	
	


// Filtro para agregar contenido a una página de WordPress
add_filter('the_content', 'clase_add_custom_content');

// Agregamos contenido sólo a la página con el título "Contenido Vinos"
function clase_add_custom_content($content)
{

	if (!is_page('CSS Colors API')) return $content;

	$html = get_data_api();
	return $content . $html;
}

// Función que se encarga de recuperar los datos de la API externa
function get_data_api()
{
	$url = 'https://api.sampleapis.com/csscolornames/colors';
	$response = wp_remote_get($url);

	if (is_wp_error($response)) {
		error_log("Error: " . $response->get_error_message());
		return false;
	}

	$body = wp_remote_retrieve_body($response);

	$data = json_decode($body);

	$template = '
					
					<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  					<div class="modal-dialog">
    					<div class="modal-content">
      						<div class="modal-header">
        						<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      						</div>
      					<div class="modal-body">
	  						<table class="table-data ">
	  							<tr>
		  							<th>ID</th>
		  							<th>Color</th>
		  							<th>Hexadecimal</th>
	  							</tr>
	  							{data}
  							</table>
     							 </div>
      							<div class="modal-footer">
        							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        							<button type="button" class="btn btn-primary">Save changes</button>
      							</div>
    							</div>
  							</div>
							</div>
					
					';

	if ($data) {
		$str = '';
		foreach ($data as $color) {
			$str .= "<tr>";
			$str .= "<td>{$color->id}</td>";
			$str .= "<td>{$color->name}</td>";
			$str .= "<td>{$color->hex}</td>";
			$str .= "</tr>";
		}
	}

	$html = str_replace('{data}', $str, $template);

	return $html;
}



	?>

